describe ("Main flow of application company", function () {
	
	it("should check correct autorization",function() {
		browser.get("http://team.binary-studio.com");
		element(by.model("authLoginCtrl.user.email")).sendKeys("tester_c@example.com");
		element(by.model("authLoginCtrl.user.password")).sendKeys("123456");
		element(by.buttonText("Log in")).click();
	});
	it ("should be able on correct page",function () {
		expect(browser.getCurrentUrl()).toEqual("http://team.binary-studio.com/#/company");
	});
	it ("check that post is created", function() {
		browser.get("http://team.binary-studio.com/#/sandbox");
		element(by.css('iframe#ui-tinymce-0_ifr')).sendKeys("aautomation by protractor");
		element(by.buttonText('Create post')).click();
	});
	it ("check that post is edited", function() {
		browser.get("http://team.binary-studio.com/#/sandbox");
		element(by.xpath("//*[@id='sandbox']/div[2]/div/div[4]/span[2]/span")).click();
		element(by.css("i.fa.fa-pencil.edit-2")).click();
		element(by.css('iframe#ui-tinymce-1_ifr')).sendKeys(" edit ");
		element(by.buttonText('Save')).click();
		
		
	});
	it ("check that post is liked", function() {
		browser.get("http://team.binary-studio.com/#/sandbox");
		element(by.xpath("//*[@id='sandbox']/div[2]/div/div[4]/span[2]/span")).click();
		element(by.css("i.fa.fa-thumbs-o-up.ng-scope")).click();
		
	});
	
	it ("check that post is commented", function() {
		browser.get("http://team.binary-studio.com/#/sandbox");
		element(by.xpath("//*[@id='sandbox']/div[2]/div/div[4]/span[2]/span")).click();
		element(by.css("div.news-input-cover.ng-scope")).click();
		element(by.css("iframe#ui-tinymce-1_ifr")).sendKeys("It is cool");
		element(by.buttonText('Add comment')).click();
		
		
	});
	it ("check that post is deleted", function() {
		browser.get("http://team.binary-studio.com/#/sandbox");
		element(by.xpath("//*[@id='sandbox']/div[2]/div/div[4]/span[2]/span")).click();
		element(by.css("i.fa.fa-times.delete-2")).click();element(by.buttonText('Yes')).click();
		
	});
});